package model;

public enum FuelType {
    DIESEL,
    ALCOHOL,
    MANPOWER,
    NUCLEAR;
}
