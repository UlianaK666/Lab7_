package model;

public enum VehicleType {
    CAR,
    BOAT,
    CHOPPER;


}
